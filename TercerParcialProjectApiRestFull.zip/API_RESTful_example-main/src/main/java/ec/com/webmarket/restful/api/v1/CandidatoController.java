package ec.com.webmarket.restful.api.v1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ec.com.webmarket.restful.common.ApiConstants;
import ec.com.webmarket.restful.dto.v1.CandidatoDTO;
import ec.com.webmarket.restful.security.ApiResponseDTO;
import ec.com.webmarket.restful.service.crud.CandidatoService;

import jakarta.validation.Valid;
import java.util.Optional;

@RestController
@RequestMapping(ApiConstants.URI_API_V1_CANDIDATOS)
public class CandidatoController {

    @Autowired
    private CandidatoService candidatoService;
    
    @GetMapping
    public ResponseEntity<ApiResponseDTO<?>> getAll() {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, candidatoService.findAll(new CandidatoDTO())));
    }

    @PostMapping
    public ResponseEntity<ApiResponseDTO<?>> create(@Valid @RequestBody CandidatoDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponseDTO<>(true, candidatoService.create(dto)));
    }

    @PutMapping
    public ResponseEntity<ApiResponseDTO<?>> update(@Valid @RequestBody CandidatoDTO dto) {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, candidatoService.update(dto)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponseDTO<?>> getById(@PathVariable Long id) {
        CandidatoDTO dto = new CandidatoDTO();
        dto.setId(id);
        Optional<CandidatoDTO> result = candidatoService.find(dto);
        if (result.isPresent()) {
            return ResponseEntity.ok(new ApiResponseDTO<>(true, result.get()));
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponseDTO<>(false, "Candidato not found"));
        }
    }
    
}


