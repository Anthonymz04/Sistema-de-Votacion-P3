package ec.com.webmarket.restful.api.v1;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ec.com.webmarket.restful.common.ApiConstants;
import ec.com.webmarket.restful.dto.v1.EstudianteDTO;
import ec.com.webmarket.restful.security.ApiResponseDTO;
import ec.com.webmarket.restful.service.crud.EstudianteService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(ApiConstants.URI_API_V1_ESTUDIANTES)
public class EstudianteController {

    @Autowired
    private EstudianteService estudianteService;

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, estudianteService.findAll(new EstudianteDTO())));
    }

    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody EstudianteDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponseDTO<>(true, estudianteService.create(dto)));
    }

    @PutMapping
    public ResponseEntity<?> update(@Valid @RequestBody EstudianteDTO dto) {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, estudianteService.update(dto)));
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponseDTO<?>> getById(@PathVariable Long id) {
        EstudianteDTO dto = new EstudianteDTO();
        dto.setId(id);
        Optional<EstudianteDTO> result = estudianteService.find(dto);
        if (result.isPresent()) {
            return ResponseEntity.ok(new ApiResponseDTO<>(true, result.get()));
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponseDTO<>(false, "Estudiante not found"));
        }
    }

    /*@GetMapping("/{id}")
    public ResponseEntity<?> getById(@Valid @PathVariable Long id) {
        EstudianteDTO dto = new EstudianteDTO();
        dto.setId(id);
        return ResponseEntity.ok(new ApiResponseDTO<>(true, estudianteService.find(dto)));
    }*/

    @GetMapping("/curso/{cursoId}")
    public ResponseEntity<?> getByCurso(@Valid @PathVariable Long cursoId) {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, estudianteService.findByCurso(cursoId)));
    }

    @GetMapping("/paralelo/{paraleloId}")
    public ResponseEntity<?> getByParalelo(@Valid @PathVariable Long paraleloId) {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, estudianteService.findByParalelo(paraleloId)));
    }
}

