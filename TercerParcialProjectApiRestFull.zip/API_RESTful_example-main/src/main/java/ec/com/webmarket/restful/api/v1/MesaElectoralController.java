package ec.com.webmarket.restful.api.v1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ec.com.webmarket.restful.common.ApiConstants;
import ec.com.webmarket.restful.dto.v1.MesaElectoralDTO;
import ec.com.webmarket.restful.security.ApiResponseDTO;
import ec.com.webmarket.restful.service.crud.MesaElectoralService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(ApiConstants.URI_API_V1_MESAS)
public class MesaElectoralController {

    @Autowired
    private MesaElectoralService mesaElectoralService;

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, mesaElectoralService.findAll(new MesaElectoralDTO())));
    }

    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody MesaElectoralDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponseDTO<>(true, mesaElectoralService.create(dto)));
    }

    @PutMapping
    public ResponseEntity<?> update(@Valid @RequestBody MesaElectoralDTO dto) {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, mesaElectoralService.update(dto)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@Valid @PathVariable Long id) {
        MesaElectoralDTO dto = new MesaElectoralDTO();
        dto.setId(id);
        return ResponseEntity.ok(new ApiResponseDTO<>(true, mesaElectoralService.find(dto)));
    }
}


