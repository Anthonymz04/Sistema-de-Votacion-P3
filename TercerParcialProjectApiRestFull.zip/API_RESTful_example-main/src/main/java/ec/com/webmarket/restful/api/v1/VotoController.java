package ec.com.webmarket.restful.api.v1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ec.com.webmarket.restful.common.ApiConstants;
import ec.com.webmarket.restful.dto.v1.VotoDTO;
import ec.com.webmarket.restful.security.ApiResponseDTO;
import ec.com.webmarket.restful.service.crud.VotoService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(ApiConstants.URI_API_V1_VOTOS)
public class VotoController {

    @Autowired
    private VotoService votoService;

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, votoService.findAll(new VotoDTO())));
    }

    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody VotoDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponseDTO<>(true, votoService.create(dto)));
    }

    @PutMapping
    public ResponseEntity<?> update(@Valid @RequestBody VotoDTO dto) {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, votoService.update(dto)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        VotoDTO dto = new VotoDTO();
        dto.setId(id);
        return ResponseEntity.ok(new ApiResponseDTO<>(true, votoService.find(dto)));
    }
}

