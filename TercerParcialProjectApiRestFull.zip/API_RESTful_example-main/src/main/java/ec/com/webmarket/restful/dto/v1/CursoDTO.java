package ec.com.webmarket.restful.dto.v1;

import lombok.Data;

@Data
public class CursoDTO {
    private Long id;
    private String nombre;
}
