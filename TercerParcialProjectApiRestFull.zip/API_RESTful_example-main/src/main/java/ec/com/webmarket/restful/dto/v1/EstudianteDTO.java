package ec.com.webmarket.restful.dto.v1;

import lombok.Data;

@Data
public class EstudianteDTO {
    private Long id;
    private String nombre;
    private Long cursoId;
    private Long paraleloId;
}
