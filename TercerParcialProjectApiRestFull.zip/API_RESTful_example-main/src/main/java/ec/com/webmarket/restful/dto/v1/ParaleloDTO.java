package ec.com.webmarket.restful.dto.v1;

import lombok.Data;

@Data
public class ParaleloDTO {
    private Long id;
    private String nombre;
}
