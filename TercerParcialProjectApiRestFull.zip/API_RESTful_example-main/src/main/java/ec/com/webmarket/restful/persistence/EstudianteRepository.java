package ec.com.webmarket.restful.persistence;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import ec.com.webmarket.restful.domain.Curso;
import ec.com.webmarket.restful.domain.Estudiante;
import ec.com.webmarket.restful.domain.Paralelo;

public interface EstudianteRepository extends JpaRepository<Estudiante, Long> {
	
    List<Estudiante> findByCurso(Curso curso);
    List<Estudiante> findByParalelo(Paralelo paralelo);
}
