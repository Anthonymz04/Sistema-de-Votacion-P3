package ec.com.webmarket.restful.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import ec.com.webmarket.restful.domain.MesaElectoral;

public interface MesaElectoralRepository extends JpaRepository<MesaElectoral, Long> {
}
