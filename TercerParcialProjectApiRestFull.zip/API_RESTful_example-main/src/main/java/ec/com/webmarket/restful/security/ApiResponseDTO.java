package ec.com.webmarket.restful.security;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class ApiResponseDTO<T> {
    private boolean success;
    private T data;
}
