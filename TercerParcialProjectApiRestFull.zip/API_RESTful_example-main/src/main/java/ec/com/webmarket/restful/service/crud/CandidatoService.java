package ec.com.webmarket.restful.service.crud;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import ec.com.webmarket.restful.domain.Candidato;
import ec.com.webmarket.restful.domain.Curso;
import ec.com.webmarket.restful.domain.Paralelo;
import ec.com.webmarket.restful.dto.v1.CandidatoDTO;
import ec.com.webmarket.restful.persistence.CandidatoRepository;
import ec.com.webmarket.restful.persistence.CursoRepository;
import ec.com.webmarket.restful.persistence.ParaleloRepository;
import ec.com.webmarket.restful.service.GenericCrudServiceImpl;

@Service
public class CandidatoService extends GenericCrudServiceImpl<Candidato, CandidatoDTO> {

    @Autowired
    private CandidatoRepository repository;

    @Autowired
    private CursoRepository cursoRepository;

    @Autowired
    private ParaleloRepository paraleloRepository;

    private ModelMapper modelMapper = new ModelMapper();

    @Override
    public Candidato mapToDomain(CandidatoDTO dto) {
        Candidato candidato = modelMapper.map(dto, Candidato.class);
        if (dto.getCursoId() != null) {
            Curso curso = cursoRepository.findById(dto.getCursoId())
                    .orElseThrow(() -> new RuntimeException("Curso not found"));
            candidato.setCurso(curso);
        }
        if (dto.getParaleloId() != null) {
            Paralelo paralelo = paraleloRepository.findById(dto.getParaleloId())
                    .orElseThrow(() -> new RuntimeException("Paralelo not found"));
            candidato.setParalelo(paralelo);
        }
        return candidato;
    }

    @Override
    public CandidatoDTO mapToDto(Candidato domain) {
        return modelMapper.map(domain, CandidatoDTO.class);
    }

    @Override
    public Long getId(CandidatoDTO dto) {
        return dto.getId();
    }

    @Override
    public JpaRepository<Candidato, Long> getRepository() {
        return repository;
    }
}
