package ec.com.webmarket.restful.service.crud;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import ec.com.webmarket.restful.domain.Curso;
import ec.com.webmarket.restful.dto.v1.CursoDTO;
import ec.com.webmarket.restful.persistence.CursoRepository;
import ec.com.webmarket.restful.service.GenericCrudServiceImpl;

@Service
public class CursoService extends GenericCrudServiceImpl<Curso, CursoDTO> {

    @Autowired
    private CursoRepository repository;

    private ModelMapper modelMapper = new ModelMapper();

    @Override
    public Curso mapToDomain(CursoDTO dto) {
        return modelMapper.map(dto, Curso.class);
    }

    @Override
    public CursoDTO mapToDto(Curso domain) {
        return modelMapper.map(domain, CursoDTO.class);
    }

    @Override
    public Long getId(CursoDTO dto) {
        return dto.getId();
    }

    @Override
    public JpaRepository<Curso, Long> getRepository() {
        return repository;
    }
}


