package ec.com.webmarket.restful.service.crud;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import ec.com.webmarket.restful.domain.Curso;
import ec.com.webmarket.restful.domain.Estudiante;
import ec.com.webmarket.restful.domain.Paralelo;
import ec.com.webmarket.restful.dto.v1.EstudianteDTO;
import ec.com.webmarket.restful.persistence.CursoRepository;
import ec.com.webmarket.restful.persistence.EstudianteRepository;
import ec.com.webmarket.restful.persistence.ParaleloRepository;
import ec.com.webmarket.restful.service.GenericCrudServiceImpl;

import java.util.List;

@Service
public class EstudianteService extends GenericCrudServiceImpl<Estudiante, EstudianteDTO> {

    @Autowired
    private EstudianteRepository repository;
    @Autowired
    private CursoRepository cursoRepository;

    @Autowired
    private ParaleloRepository paraleloRepository;
    private ModelMapper modelMapper = new ModelMapper();

    @Override
    public Estudiante mapToDomain(EstudianteDTO dto) {
        Estudiante estudiante = modelMapper.map(dto, Estudiante.class);
        if (dto.getCursoId() != null) {
            Curso curso = cursoRepository.findById(dto.getCursoId())
                    .orElseThrow(() -> new RuntimeException("Curso not found"));
            estudiante.setCurso(curso);
        }
        if (dto.getParaleloId() != null) {
            Paralelo paralelo = paraleloRepository.findById(dto.getParaleloId())
                    .orElseThrow(() -> new RuntimeException("Paralelo not found"));
            estudiante.setParalelo(paralelo);
        }
        return estudiante;
    }

    @Override
    public EstudianteDTO mapToDto(Estudiante domain) {
        return modelMapper.map(domain, EstudianteDTO.class);
    }

    @Override
    public Long getId(EstudianteDTO dto) {
        return dto.getId();
    }

    @Override
    public JpaRepository<Estudiante, Long> getRepository() {
        return repository;
    }

    public List<Estudiante> findByCurso(Long id) {
        Curso curso = new Curso();
        curso.setId(id);
        return repository.findByCurso(curso);
    }

    public List<Estudiante> findByParalelo(Long id) {
        Paralelo paralelo = new Paralelo();
        paralelo.setId(id);
        return repository.findByParalelo(paralelo);
    }
}

	


