package ec.com.webmarket.restful.service.crud;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import ec.com.webmarket.restful.domain.Candidato;
import ec.com.webmarket.restful.domain.Estudiante;
import ec.com.webmarket.restful.domain.MesaElectoral;
import ec.com.webmarket.restful.domain.Voto;
import ec.com.webmarket.restful.dto.v1.VotoDTO;
import ec.com.webmarket.restful.persistence.CandidatoRepository;
import ec.com.webmarket.restful.persistence.EstudianteRepository;
import ec.com.webmarket.restful.persistence.MesaElectoralRepository;
import ec.com.webmarket.restful.persistence.VotoRepository;
import ec.com.webmarket.restful.service.GenericCrudServiceImpl;

@Service
public class VotoService extends GenericCrudServiceImpl<Voto, VotoDTO> {

    @Autowired
    private VotoRepository repository;

    @Autowired
    private CandidatoRepository candidatoRepository;

    @Autowired
    private EstudianteRepository estudianteRepository;

    @Autowired
    private MesaElectoralRepository mesaElectoralRepository;

    private ModelMapper modelMapper = new ModelMapper();

    @Override
    public Voto mapToDomain(VotoDTO dto) {
        Voto voto = modelMapper.map(dto, Voto.class);

        if (dto.getCandidatoId() != null) {
            Candidato candidato = candidatoRepository.findById(dto.getCandidatoId())
                    .orElseThrow(() -> new RuntimeException("Candidato not found"));
            voto.setCandidato(candidato);
        }

        if (dto.getEstudianteId() != null) {
            Estudiante estudiante = estudianteRepository.findById(dto.getEstudianteId())
                    .orElseThrow(() -> new RuntimeException("Estudiante not found"));
            voto.setEstudiante(estudiante);
        }

        if (dto.getMesaId() != null) {
            MesaElectoral mesa = mesaElectoralRepository.findById(dto.getMesaId())
                    .orElseThrow(() -> new RuntimeException("Mesa Electoral not found"));
            voto.setMesa(mesa); 
        }

        return voto;
    }

    @Override
    public VotoDTO mapToDto(Voto domain) {
        return modelMapper.map(domain, VotoDTO.class);
    }

    @Override
    public Long getId(VotoDTO dto) {
        return dto.getId();
    }

    @Override
    public JpaRepository<Voto, Long> getRepository() {
        return repository;
    }
    
}



